package com.animation;

import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;

public class alpha extends Animation {
public static void al(View v) {
	AlphaAnimation animation=new AlphaAnimation(0,1);
	animation.setDuration(200);
 	v.startAnimation(animation);
}
}
