package com.animation;

import android.view.animation.Animation;
import android.view.animation.Transformation;

public class custom1 extends Animation {

 
    //动画初始化，用来设置动画的基本属性
    @Override
    public void initialize(int width, int height, int parentWidth, int parentHeight) {
        super.initialize(width, height, parentWidth, parentHeight);
        setDuration(2500);//设置动画时长
    }
 
    //该方法用来实现动画，
    // interpolatedTime表示插值器的时间因子，补间时间，取值范围0-1
    // t一个矩阵的封装类，实现动画就是利用矩阵来计算的
    @Override
    protected void applyTransformation(float interpolatedTime, Transformation t) {
        super.applyTransformation(interpolatedTime, t);
        t.setAlpha(interpolatedTime);//透明效果
        
        //Matrix可将一个点映射到另一个点，矩阵中包含了处理缩放、透视以及平移的区域，从而可用于控制实现平移、缩放、旋转等动画效果。
        //t.getMatrix().setTranslate(interpolatedTime*200,interpolatedTime*200);//平移效果

        t.getMatrix().setTranslate((float) (Math.sin(interpolatedTime*20)*50),0);//使用周期函数实现摇头效果
    }


}
