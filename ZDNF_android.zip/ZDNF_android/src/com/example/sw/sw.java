package com.example.sw;


import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.RelativeLayout;

public class sw {
public void swi(RelativeLayout layout) {
    Animation animation = new AlphaAnimation(0.7f, 1.0f);
    animation.setDuration(800);
    layout.setAnimation(animation);
/*    animation.setAnimationListener(new AnimationListener() {
        @Override
        public void onAnimationStart(Animation animation) {}
        @Override
        public void onAnimationRepeat(Animation animation) {}
        @Override
        public void onAnimationEnd(Animation animation) {}
    });*/
}
}
