package com.example.alert;

import java.lang.reflect.Field;

import com.example.zdnf_android.R;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.widget.Button;
import android.widget.TextView;

public class dialog {
	public void alert(Context context,String title,String message,String Buttontext) {
	AlertDialog dialog = new AlertDialog.Builder(context,R.style.AlertDialog)
    .setTitle(title)
    .setMessage(message)
    .setPositiveButton(Buttontext, null)
    .setIcon(R.drawable.xkicon)
    .create();
dialog.show();
//必须在调用show方法后才可修改样式
try {
Field mAlert = AlertDialog.class.getDeclaredField("mAlert");
mAlert.setAccessible(true);
Object mController = mAlert.get(dialog);
Field mMessage = mController.getClass().getDeclaredField("mMessageView");
mMessage.setAccessible(true);
TextView mMessageView = (TextView) mMessage.get(mController);
mMessageView.setTextColor(Color.BLACK);
/*Field mTitle = mController.getClass().getDeclaredField("mTitle");
mTitle.setAccessible(true);
TextView mTitleView = (TextView) mTitle.get(mController);
mTitleView.setTextColor(Color.BLACK);*/
} catch (IllegalAccessException e) {
e.printStackTrace();
} catch (NoSuchFieldException e) {
e.printStackTrace();
}
//直接获取按钮并设置
final Button pButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);//确认按键
pButton.setTextColor(Color.GRAY);
/*pButton.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v) {
    pButton.setText("点过了");
    pButton.setTextColor(Color.MAGENTA);
}
});*/
/*Button nButton = dialog.getButton(DialogInterface.BUTTON_NEGATIVE);//取消
nButton.setTextColor(Color.BLUE);*/
}
}
