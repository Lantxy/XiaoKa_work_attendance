package com.example.zdnf_android;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.animation.alpha;
import com.example.alert.dialog;
import com.example.ip.ip;
import com.example.sw.sw;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends Activity {

	//创建控件
	private EditText text1;
	private EditText text2;
	private ImageView button1;
	private ImageView button2;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		//容器对象绑定，细节，我们的容器必须和界面的控件一一匹配
		text1 =(EditText)findViewById(R.id.editText1);
		text2 =(EditText)findViewById(R.id.editText2);
		//给按钮控件，绑定了一个容器
		button1 =(ImageView) findViewById(R.id.login);
		button2 =(ImageView) findViewById(R.id.register);
		
		//点击使用监听事件，绑定监听事件
		button1.setOnClickListener(LoginBt);
		button2.setOnClickListener(RegisterBt);
		//以下为尝试的enter登录
		
		RelativeLayout layout = (RelativeLayout) findViewById(R.id.main);
		sw s =new sw();
		s.swi(layout);
	}
	//--	
	private long exitTime = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			if ((System.currentTimeMillis() - exitTime) > 2000) {
				Toast.makeText(getApplicationContext(), "小卡就要离开主人惹~",
						Toast.LENGTH_SHORT).show();
				exitTime = System.currentTimeMillis();
			} else {
				finish();
				System.exit(0);
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}


	//给button设置监听事件
	
	private android.view.View.OnClickListener LoginBt =new View.OnClickListener() {
		
		@Override
		public void onClick(View v) {
			alpha.al(v);
			//获取界面参数信息
			final String username =text1.getText().toString();
			final String password =text2.getText().toString();
			
			/*System.out.print(username+" ");
			System.out.println(password);*/
			//如何把信息从前端发送到服务器端进行数据库验证？
			
			//创建子线程 ，在安卓环境里面进行网络协议都需要这个子线程
			new Thread(new Runnable() {
				
				@Override
				public void run() {
					String url="http://"+ip.getip()+":8080/S20191027day/LoginServlet?username="+username+"&password="+password;
					//10.11.144.13
					
					//创建网络连接
					HttpGet httpget = new HttpGet(url);
					
					//创建一个客户端
					HttpClient client =new DefaultHttpClient();
					
					//执行命令
					try {
						//接受数据返回对象 数据返回对象为相应对象
						HttpResponse res = client.execute(httpget);
						
						//响应对象存在一个状态码200为访问成功 登陆失败和成功都是200，因为这个访问后台服务器成功状态就返回200
						
						if(res.getStatusLine().getStatusCode()==200) {
							//服务器访问成功
							//System.out.println("服务器后台访问成功");
							//获取服务器回传的值 以下是在响应主体内容获取参数
							HttpEntity httpEntity = res.getEntity();
							
							//获取相应主体的文本 使用IO流缓冲技术 接受/存放Http实体内容
							BufferedReader Reader = new BufferedReader(new InputStreamReader(httpEntity.getContent()));
							
							//读取缓冲里面的一行
							String str = Reader.readLine();
							
							//System.out.println("IO流缓冲里的一行："+str);
							
							if((!str.isEmpty())&&(!str.equals("登陆失败"))) {
								//跳转
								Intent intent =new Intent(MainActivity.this,DakaActivity.class);//当前的文件路径到目标文件路径
								//添加用户id给打卡页面，向下一个页面传参
								intent.putExtra("username", str);
								//启动活动页面的intent
								startActivity(intent);
								finish();
							}else {
								//登陆失败的情况下，提醒出现什么错误
								runOnUiThread(new Runnable() {
						            @Override
						            public void run() {
						            	dialog alert =new dialog();
										alert.alert(MainActivity.this,
										"小卡404",
										"您的密码或账号出错啦",
										"了解");
						            }
						        });
							}
						}
						
					} catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}).start();
			
		}
	};
	
	//给button设置监听事件
	
	private android.view.View.OnClickListener RegisterBt =new View.OnClickListener() {	
		@Override
		public void onClick(View v) {
			alpha.al(v);
			Intent intent =new Intent(MainActivity.this,RegisterActivity.class);
			startActivity(intent);
			finish();
		}
	};
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
