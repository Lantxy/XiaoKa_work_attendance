package com.example.zdnf_android;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.animation.alpha;
import com.example.alert.dialog;
import com.example.ip.ip;
import com.example.sw.sw;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class QueryActivity extends Activity {
	private CalendarView rlb;
	private ImageView fh;
	private ImageView query;
	String username;
	public int a,b,c;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_query);
		
		//绑定控件ID
		fh =(ImageView) findViewById(R.id.fh);
		query =(ImageView) findViewById(R.id.query);
		
		fh.setOnClickListener(back);
		//绑定跳转qu
		query.setOnClickListener(qu);
		
		
		rlb =(CalendarView) findViewById(R.id.rlb);
		
		rlb.setBackgroundColor(R.drawable.bg);
	    //calendarView 监听事件
	    rlb.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
	      @Override
	      public void onSelectedDayChange( CalendarView view,int year,int month,int dayOfMonth) {
	        //显示用户选择的日期
	    	  a=year;
	    	  b=month+1;
	    	  c=dayOfMonth;
	    	  //System.out.println(year + "年" + (month+1) + "月" + dayOfMonth + "日");
	      }
	    });
	    
	    
	    Intent intent = getIntent();
		//获取上一个界面给的参数
		username = intent.getStringExtra("username");
		//rlb.setFocusedMonthDateColor();
		//int a = rlb.getFocusedMonthDateColor();
		//System.out.println(a);
		RelativeLayout layout = (RelativeLayout) findViewById(R.id.main);
		sw s =new sw();
		s.swi(layout);
	}

	private long exitTime = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			if ((System.currentTimeMillis() - exitTime) > 2000) {
				Toast.makeText(getApplicationContext(), "小卡就要离开主人惹~",
						Toast.LENGTH_SHORT).show();
				exitTime = System.currentTimeMillis();
			} else {
				finish();
				System.exit(0);
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.query, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	private OnClickListener back = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// 返回事件
			alpha.al(v);
			Intent intent =new Intent(QueryActivity.this,DakaActivity.class);
			intent.putExtra("username", username);
			startActivity(intent);
			finish();
		}
	};
	
	private OnClickListener qu = new OnClickListener() {
		@Override
		public void onClick(View v) {
			alpha.al(v);
			new Thread(new Runnable() {
				@Override
				public void run() {
					String date =a+"-"+b+"-"+c;
					String url="http://"+ip.getip()+":8080/S20191027day/QueryServlet?username="+username+"&date="+date;
					HttpGet httpget = new HttpGet(url);
					HttpClient client =new DefaultHttpClient();
					try {
						HttpResponse res = client.execute(httpget);
						if(res.getStatusLine().getStatusCode()==200) {
							HttpEntity httpEntity = res.getEntity();
							BufferedReader Reader = new BufferedReader(new InputStreamReader(httpEntity.getContent()));
							final String str = Reader.readLine();
							if((!str.isEmpty())&&(!str.equals("查询失败"))) {
								//查询成功
								runOnUiThread(new Runnable() {
						            @Override
						            public void run() {
						            	String str1 =str.replace("<n>","\n");
						            	dialog alert =new dialog();
										alert.alert(QueryActivity.this,
										a+"年"+b+"月"+c+"日\r\n"+username+"的小卡",
										str1,
										"知道了");
						            }
						        });
								
							}else {
								//查询失败的情况下，提醒出现什么错误
								runOnUiThread(new Runnable() {
						            @Override
						            public void run() {
						            	dialog alert =new dialog();
										alert.alert(QueryActivity.this,
										"小卡404",
										"小卡找不到打卡记录哦",
										"了解");
						            }
						        });
							}
						}
						
					} catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}).start();
		}
	};
	
	
}
