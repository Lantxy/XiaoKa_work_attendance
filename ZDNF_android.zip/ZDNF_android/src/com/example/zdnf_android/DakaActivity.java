package com.example.zdnf_android;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.animation.alpha;
import com.animation.custom1;
import com.example.ip.ip;
import com.example.sw.sw;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("SimpleDateFormat")
public class DakaActivity extends Activity {

	//创建控件
	private TextView sj;
	private ImageView imageView_fh;
	private ImageView imageView_daka;
	private ImageView imageView_query;
	boolean bl=true;
	int i=0;
	String str="";
	String username="";
	String date_string="";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_daka);
		
		sj = (TextView) findViewById(R.id.sj);
		//绑定控件id
		imageView_fh =(ImageView) findViewById(R.id.imageView_fh);
		imageView_daka =(ImageView) findViewById(R.id.imageView_daka);
		imageView_query =(ImageView) findViewById(R.id.imageView_query);
		
		//绑定到一个控件里面
		imageView_fh.setOnClickListener(fh);
		//绑定打卡事件
		imageView_daka.setOnClickListener(dk);
		//绑定跳转qu
		imageView_query.setOnClickListener(qu);
		//打卡点击的瞬间获取上一个界面给的参数
		Intent intent = getIntent();
		//获取上一个界面给的参数
		username = intent.getStringExtra("username");
		final TextView text = (TextView) findViewById(R.id.textView3);
		//如若没有签到，则显示今日你还未签到，否则显示"勾"今日你已签到n次。
		//↑：查询本日签到的次数，需要参数：账号
		//如若本人在前2分钟内已经签到，则默认签到完成（中等）
		//或者本人在本次页面中只能签到一次（简单）
		flashtime(text);

		//定义初始时间
		SimpleDateFormat sdf = new SimpleDateFormat();
		sdf.applyPattern("HH:mm:ss");
		Date date =new Date();
		date_string = sdf.format(date);
		sj.setText(date_string);
		//多线程时间启动_________
		new Thread(new Runnable() {
			@Override
			public void run() {
				while(true) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				runOnUiThread(new Runnable() {
		            @Override
		            public void run() {
		            	SimpleDateFormat sdf = new SimpleDateFormat();//格式化时间
		        		sdf.applyPattern("HH:mm:ss");//a为am  pm
		        		Date date =new Date();
		        		date_string = sdf.format(date);
		        		sj.setText(date_string);
		            }
		        });
				}
			}
		}).start();
		//多线程_________

		Toast t=Toast.makeText(getApplicationContext(), "欢迎"+username+"主人",Toast.LENGTH_SHORT);
		t.show();
		RelativeLayout layout = (RelativeLayout) findViewById(R.id.main);
		sw s =new sw();
		s.swi(layout);
	}
	
	private long exitTime = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			if ((System.currentTimeMillis() - exitTime) > 2000) {
				Toast.makeText(getApplicationContext(), "小卡就要离开主人惹~",
						Toast.LENGTH_SHORT).show();
				exitTime = System.currentTimeMillis();
			} else {
				finish();
				System.exit(0);
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	//创建一个打卡点击事件
	private OnClickListener dk = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			if(i==0) {
			i++;
          	custom1 c=new custom1();
            v.startAnimation(c);
            sj.startAnimation(c);
			
			final TextView text = (TextView) findViewById(R.id.textView3);
			
			//打卡点击事件
			
			new Thread(new Runnable() {
				@Override
				public void run() {
					// 获取用户编号，进行打卡
					// 进行HttpGet请求
					String url ="http://"+ip.getip()+":8080/S20191027day/DakaServlet?username="+username;
					//10.51.160.84
					//101.200.44.14
					//创建一个httpGet
					HttpGet httpget = new HttpGet(url);
					
					//创建一个客户端
					HttpClient httpClient = new DefaultHttpClient();
					
					//执行网络访问
					try {
						HttpResponse res = httpClient.execute(httpget);
						
						if(res.getStatusLine().getStatusCode()==200) {
							//服务器访问成功
							//System.out.println("服务器后台访问成功");
							//获取服务器回传的值 以下是在响应主体内容获取参数
							HttpEntity httpEntity = res.getEntity();
							
							//获取相应主体的文本 使用IO流缓冲技术 接受/存放Http实体内容
							BufferedReader Reader = new BufferedReader(new InputStreamReader(httpEntity.getContent()));
							
							//读取缓冲里面的一行
							str = Reader.readLine();
							//System.out.println("IO流缓冲里的一行："+str);

							runOnUiThread(new Runnable() {
					            @Override
					            public void run() {
					            		flashtime(text);
					    				Toast t=Toast.makeText(getApplicationContext(), "✓小卡200 \n主人"+username+"，完成打卡\t\n"+str,Toast.LENGTH_SHORT);
										t.setGravity(Gravity.CENTER, 0, -500);
										t.show();
										Vibrator vibrator =(Vibrator) getSystemService(Service.VIBRATOR_SERVICE);
										vibrator.vibrate(2000);
										
					    				imageView_daka.setImageDrawable(getResources().getDrawable(R.drawable.dksbtn));
					    				
					            }
					        });
						}
						
					} catch (ClientProtocolException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}).start();
			//新还原线程
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						Thread.sleep(3000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					runOnUiThread(new Runnable() {
			            @Override
			            public void run() {
							imageView_daka.setImageDrawable(getResources().getDrawable(R.drawable.dkbtn));
							i=0;
			            }
			        });
				}
			}).start();
			
			}//if
		}
	};
	
	private OnClickListener fh = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// 返回事件
			try {
			AlertDialog dialog = new AlertDialog.Builder(DakaActivity.this,R.style.AlertDialog)
				    .setTitle("退出登录")
				    .setMessage("你要回到登录界面吗")
				    .setPositiveButton("是的", null)
				    .setNegativeButton("留下", null)
				    .setIcon(R.drawable.xkicon)
				    .create();
				dialog.show();
				Field mAlert = AlertDialog.class.getDeclaredField("mAlert");
				mAlert.setAccessible(true);
				Object mController = mAlert.get(dialog);
				Field mMessage = mController.getClass().getDeclaredField("mMessageView");
				mMessage.setAccessible(true);
				TextView mMessageView = (TextView) mMessage.get(mController);
				mMessageView.setTextColor(Color.BLACK);
				final Button pButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);//确认按键
				pButton.setTextColor(Color.GRAY);
				pButton.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						alpha.al(v);
						Intent intent = new Intent(DakaActivity.this, MainActivity.class);
						startActivity(intent);
						finish();
					}
				});
				} catch (IllegalAccessException e) {
				//e.printStackTrace();
				} catch (NoSuchFieldException e) {
				//e.printStackTrace();
				}
					
		}
	};
	
	private OnClickListener qu = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// 返回事件
			/*System.out.println("点击事件");*/
			alpha.al(v);
			Intent intent =new Intent(DakaActivity.this,QueryActivity.class);
			intent.putExtra("username", username);
			startActivity(intent);
			finish();
		}
	};
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.daka, menu);
		/*TextView text = (TextView) findViewById(R.id.text);
		text.setText("abc");*/
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void flashtime(final TextView text) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				String url ="http://"+ip.getip()+":8080/S20191027day/DakatimeServlet?username="+username;
				HttpGet httpget = new HttpGet(url);
				HttpClient httpClient = new DefaultHttpClient();
				try {
					HttpResponse res = httpClient.execute(httpget);
					if(res.getStatusLine().getStatusCode()==200) {
						HttpEntity httpEntity = res.getEntity();
						BufferedReader Reader = new BufferedReader(new InputStreamReader(httpEntity.getContent()));
						str = Reader.readLine();
						int a=Integer.parseInt(str);
						if(a>0) {
						runOnUiThread(new Runnable() {
					        @Override
					        public void run() {
					            text.setText("✓ 今日你已签到"+str+"次");
					        }
					    });
						}else {
						runOnUiThread(new Runnable() {
				            @Override
				            public void run() {
				            	text.setText("今日你还未签到");
				            }
				        });
						}
					}
				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				
				
			}
		}).start();
	}
}
