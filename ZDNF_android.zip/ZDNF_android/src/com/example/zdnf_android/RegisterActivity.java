package com.example.zdnf_android;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.animation.alpha;
import com.example.alert.dialog;
import com.example.ip.ip;
import com.example.sw.sw;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class RegisterActivity extends Activity {
	private ImageView back;
	private ImageView register;
	private EditText acc;
	private EditText ag;
	private EditText pwd;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		
		acc =(EditText)findViewById(R.id.editText1);
		ag =(EditText)findViewById(R.id.editText2);
		pwd =(EditText)findViewById(R.id.editText3);
		back =(ImageView) findViewById(R.id.back);
		register =(ImageView) findViewById(R.id.register);
		
		back.setOnClickListener(b);
		register.setOnClickListener(r);
		RelativeLayout layout = (RelativeLayout) findViewById(R.id.main);
		sw s =new sw();
		s.swi(layout);
	}

	private android.view.View.OnClickListener r =new View.OnClickListener() {	
		@Override
		public void onClick(View v) {
			alpha.al(v);
			final String username =acc.getText().toString();
			final String a =ag.getText().toString();
			final String password =pwd.getText().toString();
			//前端检测并分类提醒
			if(username.equals("")) {
				dialog alert =new dialog();
				alert.alert(RegisterActivity.this,
				"小卡拒收",
				"您的账号还没填哦",
				"对不起");
				return;
			}else if(a.equals("")) {
				dialog alert =new dialog();
				alert.alert(RegisterActivity.this,
				"小卡拒收",
				"请务必把您的年龄告诉给小卡",
				"了解");
				return;
			}else if(password.equals("")) {
				dialog alert =new dialog();
				alert.alert(RegisterActivity.this,
				"小卡拒收",
				"请让小卡记住您的小芝麻",
				"对不起");
				return;
			}
			int age=Integer.parseInt(a);
			if((age<0 )||(age>120)) {
				dialog alert =new dialog();
				alert.alert(RegisterActivity.this,
				"小卡服务异常",
				"对不起呢~主人\r\n小卡只为小于120岁的主人服务",
				"了解");
				return;
			}
			new Thread(new Runnable() {
				@Override
				public void run() {
					String url="http://"+ip.getip()+":8080/S20191027day/RegisterServlet?username="+username+"&age="+a+"&password="+password;
					HttpGet httpget = new HttpGet(url);
					HttpClient client =new DefaultHttpClient();
					try {
						HttpResponse res = client.execute(httpget);
						if(res.getStatusLine().getStatusCode()==200) {
							HttpEntity httpEntity = res.getEntity();
							BufferedReader Reader = new BufferedReader(new InputStreamReader(httpEntity.getContent()));
							String str = Reader.readLine();
							if((!str.isEmpty())&&(!str.equals("注册失败"))) {
								//成功
								runOnUiThread(new Runnable() {
						            @Override
						            public void run() {
										Toast t=Toast.makeText(getApplicationContext(), "以后您就是我的主人啦~",Toast.LENGTH_SHORT);
										t.show();
						            }
						        });
								Intent intent =new Intent(RegisterActivity.this,MainActivity.class);
								startActivity(intent);
								finish();
							}else {
								runOnUiThread(new Runnable() {
						            @Override
						            public void run() {
						            	dialog alert =new dialog();
										alert.alert(RegisterActivity.this,
										"小卡200",
										"您的用户名被其他人注册过啦",
										"换一个");
						            }
						        });
							}
							
						}
						
						
					} catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}).start();
			
			
		}
	};
	
	private long exitTime = 0;
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			if ((System.currentTimeMillis() - exitTime) > 2000) {
				Toast.makeText(getApplicationContext(), "小卡就要离开主人惹~",
						Toast.LENGTH_SHORT).show();
				exitTime = System.currentTimeMillis();
			} else {
				finish();
				System.exit(0);
			}
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	
	private android.view.View.OnClickListener b =new View.OnClickListener() {	
		@Override
		public void onClick(View v) {
			alpha.al(v);
			Intent intent =new Intent(RegisterActivity.this,MainActivity.class);
			startActivity(intent);
			finish();
		}
	};
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.register, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
