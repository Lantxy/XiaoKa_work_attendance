package com.example.ip;

public class ip {
public static String getip() {
	return "101.200.44.14";
}
}
